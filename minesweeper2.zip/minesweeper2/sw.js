/**
 * Welcome to your Workbox-powered service worker!
 *
 * You'll need to register this file in your web app and you should
 * disable HTTP caching for this file too.
 * See https://goo.gl/nhQhGp
 *
 * The rest of the code is auto-generated. Please don't update this file
 * directly; instead, make changes to your Workbox build configuration
 * and re-run your build process.
 * See https://goo.gl/2aRDsh
 */

importScripts("https://storage.googleapis.com/workbox-cdn/releases/3.6.3/workbox-sw.js");

/**
 * The workboxSW.precacheAndRoute() method efficiently caches and responds to
 * requests for URLs in the manifest.
 * See https://goo.gl/S9QRab
 */
self.__precacheManifest = [
  {
    "url": "favicon.30dd5a83.png",
    "revision": "197834d1053d95a70eb28280b0e48373"
  },
  {
    "url": "HoneyRoom.d3698231.ttf",
    "revision": "8ca0d9a4b53ea5d23543652041781478"
  },
  {
    "url": "index.html",
    "revision": "828494b5235562a9d531b0219099ee45"
  },
  {
    "url": "js.77e42ee7.css",
    "revision": "471b2a486b30a90a033cf31ce8a6c0e4"
  },
  {
    "url": "js.b9b1a95b.js",
    "revision": "2e7de6c6f9e986e9b399cccd86dc4f0c"
  },
  {
    "url": "styles.505e7ee1.css",
    "revision": "82f222b154df936facaac6df6dab13bf"
  }
].concat(self.__precacheManifest || []);
workbox.precaching.suppressWarnings();
workbox.precaching.precacheAndRoute(self.__precacheManifest, {});
