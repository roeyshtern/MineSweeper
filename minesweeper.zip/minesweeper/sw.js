/**
 * Welcome to your Workbox-powered service worker!
 *
 * You'll need to register this file in your web app and you should
 * disable HTTP caching for this file too.
 * See https://goo.gl/nhQhGp
 *
 * The rest of the code is auto-generated. Please don't update this file
 * directly; instead, make changes to your Workbox build configuration
 * and re-run your build process.
 * See https://goo.gl/2aRDsh
 */

importScripts("https://storage.googleapis.com/workbox-cdn/releases/3.6.3/workbox-sw.js");

/**
 * The workboxSW.precacheAndRoute() method efficiently caches and responds to
 * requests for URLs in the manifest.
 * See https://goo.gl/S9QRab
 */
self.__precacheManifest = [
  {
    "url": "favicon.30dd5a83.png",
    "revision": "197834d1053d95a70eb28280b0e48373"
  },
  {
    "url": "HoneyRoom.d3698231.ttf",
    "revision": "8ca0d9a4b53ea5d23543652041781478"
  },
  {
    "url": "index.html",
    "revision": "a4451cf9da097865612fae804b14686d"
  },
  {
    "url": "js.801270e0.css",
    "revision": "1ffed813c8bd55a85a8b01daa54c29c0"
  },
  {
    "url": "js.9a3f03f0.js",
    "revision": "2e7de6c6f9e986e9b399cccd86dc4f0c"
  },
  {
    "url": "styles.505e7ee1.css",
    "revision": "82f222b154df936facaac6df6dab13bf"
  }
].concat(self.__precacheManifest || []);
workbox.precaching.suppressWarnings();
workbox.precaching.precacheAndRoute(self.__precacheManifest, {});
